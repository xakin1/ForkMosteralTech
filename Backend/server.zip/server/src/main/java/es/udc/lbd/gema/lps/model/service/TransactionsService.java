package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.service.dto.TransactionsDTO;
import es.udc.lbd.gema.lps.model.service.dto.TransactionsFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TransactionsService {

  Page<TransactionsDTO> getAll(Pageable pageable, List<String> filters, String search);

  TransactionsFullDTO get(Long id) throws NotFoundException;

  TransactionsFullDTO create(TransactionsFullDTO transactions) throws OperationNotAllowedException;

  TransactionsFullDTO update(Long id, TransactionsFullDTO transactions)
      throws OperationNotAllowedException;

  void delete(Long id);
}
