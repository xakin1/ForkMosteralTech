package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.domain.Appliances;
import es.udc.lbd.gema.lps.model.repository.AppliancesRepository;
import es.udc.lbd.gema.lps.model.service.dto.AppliancesDTO;
import es.udc.lbd.gema.lps.model.service.dto.AppliancesFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import es.udc.lbd.gema.lps.web.rest.specifications.AppliancesSpecification;
import es.udc.lbd.gema.lps.web.rest.util.specification_utils.*;
import java.util.List;
import javax.inject.Inject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class AppliancesServiceImpl implements AppliancesService {

  @Inject private AppliancesRepository appliancesRepository;

  public Page<AppliancesDTO> getAll(Pageable pageable, List<String> filters, String search) {
    Page<Appliances> page;
    if (search != null && !search.isEmpty()) {
      page = appliancesRepository.findAll(AppliancesSpecification.searchAll(search), pageable);
    } else {
      page =
          appliancesRepository.findAll(
              SpecificationUtil.getSpecificationFromFilters(filters, false), pageable);
    }
    return page.map(AppliancesDTO::new);
  }

  public AppliancesFullDTO get(Long id) throws NotFoundException {
    Appliances appliances = findById(id);
    return new AppliancesFullDTO(appliances);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public AppliancesFullDTO create(AppliancesFullDTO appliancesDto)
      throws OperationNotAllowedException {
    if (appliancesDto.getId() != null) {
      throw new OperationNotAllowedException("appliances.error.id-exists");
    }
    Appliances appliancesEntity = appliancesDto.toAppliances();
    Appliances appliancesSaved = appliancesRepository.save(appliancesEntity);
    return new AppliancesFullDTO(appliancesSaved);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public AppliancesFullDTO update(Long id, AppliancesFullDTO appliancesDto)
      throws OperationNotAllowedException {
    if (appliancesDto.getId() == null) {
      throw new OperationNotAllowedException("appliances.error.id-not-exists");
    }
    if (!id.equals(appliancesDto.getId())) {
      throw new OperationNotAllowedException("appliances.error.id-dont-match");
    }
    Appliances appliances =
        appliancesRepository
            .findById(id)
            .orElseThrow(() -> new OperationNotAllowedException("appliances.error.id-not-exists"));
    Appliances appliancesToUpdate = appliancesDto.toAppliances();
    Appliances appliancesUpdated = appliancesRepository.save(appliancesToUpdate);
    return new AppliancesFullDTO(appliancesUpdated);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public void delete(Long id) {
    appliancesRepository.deleteById(id);
  }

  /** PRIVATE METHODS * */
  private Appliances findById(Long id) throws NotFoundException {
    return appliancesRepository
        .findById(id)
        .orElseThrow(() -> new NotFoundException("Cannot find Appliances with id " + id));
  }
}
