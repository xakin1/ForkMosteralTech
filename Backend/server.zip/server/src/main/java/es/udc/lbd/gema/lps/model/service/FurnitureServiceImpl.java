package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.domain.Furniture;
import es.udc.lbd.gema.lps.model.repository.FurnitureRepository;
import es.udc.lbd.gema.lps.model.service.dto.FurnitureDTO;
import es.udc.lbd.gema.lps.model.service.dto.FurnitureFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import es.udc.lbd.gema.lps.web.rest.specifications.FurnitureSpecification;
import es.udc.lbd.gema.lps.web.rest.util.specification_utils.*;
import java.util.List;
import javax.inject.Inject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class FurnitureServiceImpl implements FurnitureService {

  @Inject private FurnitureRepository furnitureRepository;

  public Page<FurnitureDTO> getAll(Pageable pageable, List<String> filters, String search) {
    Page<Furniture> page;
    if (search != null && !search.isEmpty()) {
      page = furnitureRepository.findAll(FurnitureSpecification.searchAll(search), pageable);
    } else {
      page =
          furnitureRepository.findAll(
              SpecificationUtil.getSpecificationFromFilters(filters, false), pageable);
    }
    return page.map(FurnitureDTO::new);
  }

  public FurnitureFullDTO get(Long id) throws NotFoundException {
    Furniture furniture = findById(id);
    return new FurnitureFullDTO(furniture);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public FurnitureFullDTO create(FurnitureFullDTO furnitureDto)
      throws OperationNotAllowedException {
    if (furnitureDto.getId() != null) {
      throw new OperationNotAllowedException("furniture.error.id-exists");
    }
    Furniture furnitureEntity = furnitureDto.toFurniture();
    Furniture furnitureSaved = furnitureRepository.save(furnitureEntity);
    return new FurnitureFullDTO(furnitureSaved);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public FurnitureFullDTO update(Long id, FurnitureFullDTO furnitureDto)
      throws OperationNotAllowedException {
    if (furnitureDto.getId() == null) {
      throw new OperationNotAllowedException("furniture.error.id-not-exists");
    }
    if (!id.equals(furnitureDto.getId())) {
      throw new OperationNotAllowedException("furniture.error.id-dont-match");
    }
    Furniture furniture =
        furnitureRepository
            .findById(id)
            .orElseThrow(() -> new OperationNotAllowedException("furniture.error.id-not-exists"));
    Furniture furnitureToUpdate = furnitureDto.toFurniture();
    Furniture furnitureUpdated = furnitureRepository.save(furnitureToUpdate);
    return new FurnitureFullDTO(furnitureUpdated);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public void delete(Long id) {
    furnitureRepository.deleteById(id);
  }

  /** PRIVATE METHODS * */
  private Furniture findById(Long id) throws NotFoundException {
    return furnitureRepository
        .findById(id)
        .orElseThrow(() -> new NotFoundException("Cannot find Furniture with id " + id));
  }
}
