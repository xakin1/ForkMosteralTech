package es.udc.lbd.gema.lps.model.domain;

public enum State {
  SECOND_HAND,
  NEW,
  SEMI_NEW
}
