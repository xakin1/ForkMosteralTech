package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.service.dto.FurnitureDTO;
import es.udc.lbd.gema.lps.model.service.dto.FurnitureFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FurnitureService {

  Page<FurnitureDTO> getAll(Pageable pageable, List<String> filters, String search);

  FurnitureFullDTO get(Long id) throws NotFoundException;

  FurnitureFullDTO create(FurnitureFullDTO furniture) throws OperationNotAllowedException;

  FurnitureFullDTO update(Long id, FurnitureFullDTO furniture) throws OperationNotAllowedException;

  void delete(Long id);
}
