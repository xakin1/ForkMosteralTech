package es.udc.lbd.gema.lps.model.service.dto;

import es.udc.lbd.gema.lps.model.domain.*;

public class ProductDTO {

  private Long id;
  private String name;
  private String description;
  private State state;
  private UserDTO owner;

  public ProductDTO() {}

  public ProductDTO(Product product) {
    this.id = product.getId();
    this.name = product.getName();
    this.description = product.getDescription();
    this.state = product.getState();
    if (product.getOwner() != null) {
      this.owner = new UserDTO(product.getOwner());
    }
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public State getState() {
    return state;
  }

  public void setState(State state) {
    this.state = state;
  }

  public UserDTO getOwner() {
    return owner;
  }

  public void setOwner(UserDTO owner) {
    this.owner = owner;
  }

  public Product toProduct() {
    Product product = new Product();
    product.setId(this.getId());
    product.setName(this.getName());
    product.setDescription(this.getDescription());
    product.setState(this.getState());
    if (this.getOwner() != null) {
      product.setOwner(this.getOwner().toUser());
    }
    return product;
  }
}
