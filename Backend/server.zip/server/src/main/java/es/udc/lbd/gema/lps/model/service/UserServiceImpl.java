package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.domain.User;
import es.udc.lbd.gema.lps.model.repository.UserRepository;
import es.udc.lbd.gema.lps.model.service.dto.UserDTO;
import es.udc.lbd.gema.lps.model.service.dto.UserFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import es.udc.lbd.gema.lps.web.rest.custom.FeatureCollectionJSON;
import es.udc.lbd.gema.lps.web.rest.custom.FeatureJSON;
import es.udc.lbd.gema.lps.web.rest.specifications.UserSpecification;
import es.udc.lbd.gema.lps.web.rest.util.specification_utils.*;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import javax.inject.Inject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class UserServiceImpl implements UserService {

  @Inject private UserRepository userRepository;

  public Page<UserDTO> getAll(Pageable pageable, List<String> filters, String search) {
    Page<User> page;
    if (search != null && !search.isEmpty()) {
      page = userRepository.findAll(UserSpecification.searchAll(search), pageable);
    } else {
      page =
          userRepository.findAll(
              SpecificationUtil.getSpecificationFromFilters(filters, false), pageable);
    }
    return page.map(UserDTO::new);
  }

  public FeatureCollectionJSON getLocation(Boolean properties, List<String> filters) {
    List<User> list =
        userRepository.findAll(SpecificationUtil.getSpecificationFromFilters(filters, false));

    List<FeatureJSON> ret =
        list.stream()
            .map(
                e -> {
                  FeatureJSON geoJSON = new FeatureJSON();
                  if (properties) {
                    geoJSON = new FeatureJSON(User.class, e);
                  } else {
                    geoJSON.setProperties(new HashMap());
                  }
                  geoJSON.setId(e.getId());
                  geoJSON.getProperties().put("displayString", "" + e.getId() + "");
                  geoJSON.setGeometry(e.getLocation());
                  return geoJSON;
                })
            .filter(e -> e.getGeometry() != null)
            .collect(Collectors.toList());
    return new FeatureCollectionJSON(ret);
  }

  public UserFullDTO get(Long id) throws NotFoundException {
    User user = findById(id);
    return new UserFullDTO(user);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public UserFullDTO create(UserFullDTO userDto) throws OperationNotAllowedException {
    if (userDto.getId() != null) {
      throw new OperationNotAllowedException("user.error.id-exists");
    }
    User userEntity = userDto.toUser();
    User userSaved = userRepository.save(userEntity);
    return new UserFullDTO(userSaved);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public UserFullDTO update(Long id, UserFullDTO userDto) throws OperationNotAllowedException {
    if (userDto.getId() == null) {
      throw new OperationNotAllowedException("user.error.id-not-exists");
    }
    if (!id.equals(userDto.getId())) {
      throw new OperationNotAllowedException("user.error.id-dont-match");
    }
    User user =
        userRepository
            .findById(id)
            .orElseThrow(() -> new OperationNotAllowedException("user.error.id-not-exists"));
    User userToUpdate = userDto.toUser();
    User userUpdated = userRepository.save(userToUpdate);
    return new UserFullDTO(userUpdated);
  }

  @Transactional(readOnly = false, rollbackFor = Exception.class)
  public void delete(Long id) {
    userRepository.deleteById(id);
  }

  /** PRIVATE METHODS * */
  private User findById(Long id) throws NotFoundException {
    return userRepository
        .findById(id)
        .orElseThrow(() -> new NotFoundException("Cannot find User with id " + id));
  }
}
