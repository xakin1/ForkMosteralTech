package es.udc.lbd.gema.lps.model.domain;

public enum TransactionActions {
  BUY,
  SALE
}
