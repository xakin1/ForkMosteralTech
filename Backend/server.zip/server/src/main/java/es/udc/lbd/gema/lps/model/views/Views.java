package es.udc.lbd.gema.lps.model.views;

public class Views {
  // thought for sending collections of the entity such as lists
  public static class General {}

  // thought for sending a single entity
  public static class Detailed extends General {}
}
