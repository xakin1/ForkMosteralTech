package es.udc.lbd.gema.lps.model.service;

import es.udc.lbd.gema.lps.model.service.dto.ProductDTO;
import es.udc.lbd.gema.lps.model.service.dto.ProductFullDTO;
import es.udc.lbd.gema.lps.model.service.exceptions.NotFoundException;
import es.udc.lbd.gema.lps.model.service.exceptions.OperationNotAllowedException;
import es.udc.lbd.gema.lps.web.rest.custom.FeatureCollectionJSON;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProductService {

  Page<ProductDTO> getAll(Pageable pageable, List<String> filters, String search);

  FeatureCollectionJSON getLocation(Boolean properties, List<String> filters);

  ProductFullDTO get(Long id) throws NotFoundException;

  ProductFullDTO create(ProductFullDTO product) throws OperationNotAllowedException;

  ProductFullDTO update(Long id, ProductFullDTO product) throws OperationNotAllowedException;

  void delete(Long id);
}
